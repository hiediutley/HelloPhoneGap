//
//  main.m
//  HelloPhoneGap
//
//  Created by Hiedi Utley on 3/14/11.
//  Copyright Chariot Solutions, LLC 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"HelloPhoneGapAppDelegate");
    [pool release];
    return retVal;
}
